# QA-only settings (NOT part of the repo): real Postgres + real Redis (as in production);
# only throttling is relaxed so automated browsing is not rate-limited.
from core.settings.development import *  # noqa
CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = False
REST_FRAMEWORK = {**REST_FRAMEWORK}
for k in list(REST_FRAMEWORK.get("DEFAULT_THROTTLE_RATES", {})):
    REST_FRAMEWORK["DEFAULT_THROTTLE_RATES"][k] = "100000/min"
MEDIA_ROOT = "/home/claude/qa/media"
