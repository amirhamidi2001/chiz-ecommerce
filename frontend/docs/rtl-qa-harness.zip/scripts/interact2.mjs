import { launch, newCtx, watch, settle, audit, BASE } from './harness.mjs';
const b = await launch(); const out = {};
const S = async (name, fn) => { try { await fn(); } catch (e) { out[name + '_ERR'] = String(e).slice(0, 200); } console.log(name, JSON.stringify(out[name] ?? out[name + '_ERR'])); };
const brief = (a) => ({ clipped: a.clipped.map(c => `${c.el.slice(0,50)} [${c.left}..${c.right}]`), leftHug: a.leftHug.map(x => x.el.slice(0,50)), ltrFa: a.ltrPersian.map(x => x.el.slice(0,50)) });
const MOB = { width: 390, height: 844 };
async function go(ctx, path) { const p = await ctx.newPage(); watch(p); await p.goto(BASE + path, { waitUntil: 'domcontentloaded' }); await settle(p, 900); return p; }
const rects = (p, sel) => p.evaluate((s) => [...document.querySelectorAll(s)].filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }).slice(0, 6).map(e => { const r = e.getBoundingClientRect(); return { cls: String(e.className).slice(0, 70), left: Math.round(r.left), right: Math.round(r.right), w: Math.round(r.width) }; }), sel);

await S('storefrontMobileMenu', async () => {
  const ctx = await newCtx(b, 'customer', MOB); const p = await go(ctx, '/');
  const btn = p.locator('header button:has(i.bi-list), header button[aria-label*="enu" i]').first(); out.found = await btn.count();
  await btn.click({ timeout: 3000 }); await p.waitForTimeout(600);
  await p.screenshot({ path: 'shots/i-m-menu.png' });
  out.storefrontMobileMenu = { found: out.found, audit: brief(await audit(p)), panels: await rects(p, 'header nav, header [class*="fixed"], header [class*="absolute"][class*="inset"], aside') };
  await ctx.close();
});
await S('adminMobileSidebar', async () => {
  const ctx = await newCtx(b, 'admin', MOB); const p = await go(ctx, '/admin');
  await p.screenshot({ path: 'shots/i-m-admin-closed.png' });
  const btn = p.locator('header button').first(); await btn.click({ timeout: 3000 }); await p.waitForTimeout(700);
  await p.screenshot({ path: 'shots/i-m-admin-open.png' });
  out.adminMobileSidebar = { audit: brief(await audit(p)), aside: await rects(p, 'aside') };
  await ctx.close();
});
await S('analyticsOverflow', async () => {
  const ctx = await newCtx(b, 'admin', MOB); const p = await go(ctx, '/admin/analytics');
  out.analyticsOverflow = await p.evaluate(() => { const m = document.querySelector('main'); const mr = m.getBoundingClientRect(); return [...m.querySelectorAll('*')].filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && (r.right > mr.right + 2 || r.left < mr.left - 2) && e.parentElement.getBoundingClientRect().right <= mr.right + 2; }).slice(0, 5).map(e => ({ el: e.tagName + '.' + String(e.className).slice(0, 80), left: Math.round(e.getBoundingClientRect().left), right: Math.round(e.getBoundingClientRect().right), w: Math.round(e.getBoundingClientRect().width) })); });
  await ctx.close();
});
await S('chatWidget', async () => {
  const ctx = await newCtx(b, 'customer'); const p = await go(ctx, '/');
  out.chatBtn = await rects(p, 'button.fixed, div.fixed button');
  const btn = p.locator('button.fixed').last(); await btn.click({ timeout: 3000 }); await p.waitForTimeout(700);
  await p.screenshot({ path: 'shots/i-chat-open.png' });
  out.chatWidget = { btnBefore: out.chatBtn, panel: await rects(p, '[class*="fixed"]'), audit: brief(await audit(p)) };
  await ctx.close();
});
await S('adminCouponModal', async () => {
  const ctx = await newCtx(b, 'admin'); const p = await go(ctx, '/admin/coupons');
  await p.getByRole('button', { name: /add|new|create/i }).first().click({ timeout: 3000 }); await p.waitForTimeout(700);
  await p.screenshot({ path: 'shots/i-admin-coupon-modal.png' });
  out.adminCouponModal = { audit: brief(await audit(p)), modal: await rects(p, '[role=dialog], div.fixed.inset-0 > div') };
  await ctx.close();
});
await S('adminOrderRow', async () => {
  const ctx = await newCtx(b, 'admin'); const p = await go(ctx, '/admin/orders');
  await p.locator('tbody tr').first().click({ timeout: 3000 }).catch(() => {}); await p.waitForTimeout(700);
  await p.screenshot({ path: 'shots/i-admin-order-detail.png' });
  out.adminOrderRow = { audit: brief(await audit(p)) };
  await ctx.close();
});
await b.close();
