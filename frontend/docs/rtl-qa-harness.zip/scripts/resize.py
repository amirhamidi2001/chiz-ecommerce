import sys
from PIL import Image
Image.MAX_IMAGE_PIXELS=None
name=sys.argv[1]; w=int(sys.argv[2]) if len(sys.argv)>2 else 1000; sl=int(sys.argv[3]) if len(sys.argv)>3 else 1300
im=Image.open(f'shots/{name}.png').convert('RGB'); s=w/im.width; im=im.resize((w,int(im.height*s)))
n=-(-im.height//sl)
for i in range(n): im.crop((0,i*sl,w,min(im.height,(i+1)*sl))).save(f'view/{name}-{i}.jpg',quality=72)
print(name,im.height,n)
