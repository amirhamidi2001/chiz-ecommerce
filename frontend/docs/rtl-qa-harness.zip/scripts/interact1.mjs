import { launch, newCtx, watch, settle, audit, BASE } from './harness.mjs';
const b = await launch();
const brief = (a) => ({ ovf: a.docOverflowPx, clipped: a.clipped.map(c => `${c.el} [${c.left}..${c.right}]`), ltrFa: a.ltrPersian.map(x => x.el), leftHug: a.leftHug.map(x => x.el) });
const out = {}; const S = async (name, fn) => { try { await fn(); } catch (e) { out[name+'_ERR'] = String(e).slice(0,160); } console.log(name, JSON.stringify(out, null, 0).slice(-1800)); };
async function go(ctx, path) { const p = await ctx.newPage(); watch(p); await p.goto(BASE + path, { waitUntil: 'domcontentloaded' }); await settle(p, 900); return p; }

// S1/S2/S3 — PDP: gallery, variant switch, reviews tab (p1 has store reply + review images)
await S('s0', async () => {

  const ctx = await newCtx(b, 'anon'); let p = await go(ctx, '/product/p4');
  const counter = async () => (await p.locator('text=/\\d+ \\/ \\d+/').first().innerText().catch(() => '?')).trim();
  const thumbs = async () => p.evaluate(() => [...document.querySelectorAll('img')].filter(i => i.closest('button') && i.getBoundingClientRect().width < 120 && i.getBoundingClientRect().top > 300 && i.getBoundingClientRect().top < 800).map(i => ({ x: Math.round(i.getBoundingClientRect().left), ring: /ring|border-teal/.test(i.closest('button').className) })));
  out.gallery = { start: await counter(), thumbsStart: await thumbs() };
  await p.getByLabel('Next image').click(); await p.waitForTimeout(300); out.gallery.afterNext = await counter();
  await p.getByLabel('Next image').click(); await p.waitForTimeout(300); out.gallery.afterNext2 = await counter();
  await p.getByLabel('Next image').click(); await p.waitForTimeout(300); out.gallery.afterNext3_wrap = await counter();
  await p.getByLabel('Previous image').click(); await p.waitForTimeout(300); out.gallery.afterPrev = await counter();
  out.gallery.thumbsEnd = await thumbs();
  // variant swatches: click 2nd swatch, read price + selected label
  const sw = p.locator('button[class*="rounded-full"]'); out.swatchCount = await sw.count();
  const price = async () => (await p.locator('text=/تومان/').first().innerText()).replace(/\s+/g, ' ');
  out.priceBefore = await price(); await sw.nth(2).click().catch(() => {}); await p.waitForTimeout(400); out.priceAfter = await price();
  await p.close();
  p = await go(ctx, '/product/p1');
  await p.getByRole('button', { name: /Reviews/ }).first().click().catch(async () => p.locator('text=/^Reviews/').first().click());
  await p.waitForTimeout(800);
  await p.screenshot({ path: 'shots/i-pdp-reviews.png', fullPage: true });
  out.pdpReviewsAudit = brief(await audit(p));
  await p.close(); await ctx.close();
});

// S4 — header dropdowns + search suggestions (desktop, customer)
await S('s1', async () => {

  const ctx = await newCtx(b, 'customer'); let p = await go(ctx, '/');
  const inp = p.locator('input[placeholder*="Search"]').first(); await inp.click(); await inp.fill('کرم'); await p.waitForTimeout(1200);
  await p.screenshot({ path: 'shots/i-search-suggest.png', clip: { x: 0, y: 0, width: 1366, height: 520 } });
  out.suggestAudit = brief(await audit(p));
  await inp.fill(''); await p.keyboard.press('Escape');
  const acct = p.locator('header button:has(i.bi-person), header a:has(i.bi-person), header [class*="bi-person"]').first();
  out.acctFound = await acct.count();
  await acct.click({ timeout: 3000 }).catch(e => out.acctErr = String(e).slice(0, 80)); await p.waitForTimeout(500);
  await p.screenshot({ path: 'shots/i-account-menu.png', clip: { x: 0, y: 0, width: 1366, height: 520 } });
  out.acctMenuAudit = brief(await audit(p));
  await p.close(); await ctx.close();
});

// S5 — cart coupon
await S('s2', async () => {

  const ctx = await newCtx(b, 'customer'); const p = await go(ctx, '/cart');
  const ci = p.locator('input[placeholder*="oupon" i], input[placeholder*="code" i]').first(); out.couponInput = await ci.count();
  await ci.fill('NOPE123'); await p.getByRole('button', { name: /apply/i }).first().click(); await p.waitForTimeout(900);
  await p.screenshot({ path: 'shots/i-cart-coupon-bad.png', fullPage: true });
  await ci.fill('SAVE10'); await p.getByRole('button', { name: /apply/i }).first().click().catch(() => {}); await p.waitForTimeout(1200);
  await p.screenshot({ path: 'shots/i-cart-coupon-ok.png', fullPage: true });
  out.cartAudit = brief(await audit(p));
  await p.close(); await ctx.close();
});

// S7 — bidi in LTR-content inputs (phone/email)
await S('s3', async () => {

  const ctx = await newCtx(b, 'customer'); const p = await go(ctx, '/account?tab=settings');
  const tel = p.locator('input[type=tel]').first(); await tel.fill('+989121234567'); 
  const p2 = await go(ctx, '/contact'); await p2.locator('input[type=email]').first().fill('ali.reza@example.com.'); await p2.screenshot({ path: 'shots/i-contact-email.png', clip: { x: 0, y: 150, width: 1366, height: 700 } }); out.contactEmail = await p2.evaluate(() => { const i=document.querySelector('input[type=email]'); return {dir:getComputedStyle(i).direction, align:getComputedStyle(i).textAlign}; });
  await p.screenshot({ path: 'shots/i-inputs-bidi.png', fullPage: false, clip: { x: 0, y: 0, width: 1366, height: 900 } });
  out.settingsInputs = await p.evaluate(() => [...document.querySelectorAll('input[type=tel],input[type=email]')].map(i => ({ type: i.type, value: i.value, dir: getComputedStyle(i).direction, align: getComputedStyle(i).textAlign })));
  await p.close(); await ctx.close();

});
console.log(JSON.stringify(out, null, 1));
await b.close();
