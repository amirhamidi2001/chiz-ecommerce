import { launch, newCtx, watch, settle, audit, BASE } from './harness.mjs';
import fs from 'node:fs';
const ROUTES = JSON.parse(fs.readFileSync(process.argv[2] || 'routes.json', 'utf8'));
const only = process.argv[3];
const b = await launch();
const results = {};
for (const vpName of (process.env.VPS || 'desktop,mobile').split(',')) {
  const vp = vpName === 'desktop' ? { width: 1366, height: 900 } : { width: 390, height: 844 };
  const ctxs = {};
  for (const r of ROUTES) {
    if (only && !r.id.includes(only)) continue;
    ctxs[r.role] ??= await newCtx(b, r.role, vp);
    const page = await ctxs[r.role].newPage(); const log = watch(page);
    try {
      await page.goto(BASE + r.path, { waitUntil: 'domcontentloaded' }); await settle(page, 900);
      if (r.pre) await r.pre.split('|').reduce(async (p, sel) => { await p; const l = page.locator(sel).first(); if (await l.count()) { await l.click({ timeout: 2000 }).catch(() => {}); await page.waitForTimeout(500); } }, Promise.resolve());
      const a = await audit(page);
      await page.screenshot({ path: `shots/${vpName}-${r.id}.png`, fullPage: true });
      results[`${vpName}:${r.id}`] = { path: r.path, finalUrl: page.url().replace(BASE, ''), ...a, log };
    } catch (e) { results[`${vpName}:${r.id}`] = { path: r.path, fatal: String(e).slice(0, 200), log }; }
    await page.close();
  }
  for (const c of Object.values(ctxs)) await c.close();
}
fs.writeFileSync(process.argv[4] || 'results.json', JSON.stringify(results, null, 1));
for (const [k, v] of Object.entries(results)) console.log(k.padEnd(34), v.fatal ? 'FATAL ' + v.fatal : `→${v.finalUrl.slice(0, 22).padEnd(22)} ovf=${v.docOverflowPx} clip=${v.clipped.length} ltrFa=${v.ltrPersian.length} leftHug=${v.leftHug.length} scrl=${v.scrollers.length} err=${v.log.errors.length} http4xx=${v.log.failed.length}`);
await b.close();
