import sys
from PIL import Image
out=sys.argv[1]; names=sys.argv[2:]
W=520; H=420; cols=3; rows=-(-len(names)//cols)
sh=Image.new('RGB',(cols*W,rows*H),'white')
for i,n in enumerate(names):
    im=Image.open(f'shots/{n}.png').convert('RGB'); s=W/im.width; im=im.resize((W,int(im.height*s))).crop((0,0,W,H))
    sh.paste(im,((i%cols)*W,(i//cols)*H))
sh.save(f'view/{out}.jpg',quality=72); print(sh.size)
