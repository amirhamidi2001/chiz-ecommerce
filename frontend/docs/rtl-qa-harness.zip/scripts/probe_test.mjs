import { launch, newCtx, settle, audit, BASE } from './harness.mjs';
const b = await launch(); const ctx = await newCtx(b, 'anon'); const p = await ctx.newPage();
await p.goto(BASE + '/about', { waitUntil: 'domcontentloaded' }); await settle(p);
// inject known-bad cases
await p.evaluate(() => {
  const d = document.createElement('div'); d.id = 'bad'; d.style.cssText = 'width:600px;margin:10px';
  d.innerHTML = `
   <p style="direction:ltr;text-align:left;border:1px solid red">این یک متن فارسی با جهت اشتباه چپ‌به‌راست است که باید راست‌چین باشد</p>
   <p id="hug" style="text-align:left;border:1px solid red">متن فارسی چسبیده به چپ</p>
   <div style="width:2000px;height:20px;background:red">wide</div>
   <input id="eml" type="email" placeholder="ایمیل" style="direction:ltr;text-align:left">
   <i class="bi bi-chevron-right"></i><button aria-label="Next"><i class="bi bi-chevron-right"></i></button>
   <div style="overflow-x:auto;width:200px"><div style="width:800px;display:flex"><span style="width:100px">a</span></div></div>`;
  document.body.prepend(d);
});
const a = await audit(p);
const brief = { docOverflowPx: a.docOverflowPx, clipped: a.clipped.length, ltrPersian: a.ltrPersian.map(x=>x.el), leftHug: a.leftHug.map(x=>x.el), scrollers: a.scrollers.map(x=>x.el+' L='+x.scrollLeft), icons: a.icons.filter(i=>i.y<400).map(i=>i.icon+' mirrored='+i.mirrored+' points='+i.visualPoints+' ctl='+i.inControl) , inputs: a.inputs.filter(i=>i.name==='eml'||i.el.includes('eml')).map(i=>i.type+' dir='+i.dirAttr)};
console.log(JSON.stringify(brief, null, 1));
await b.close();
