import { launch, newCtx, settle, audit, BASE } from './harness.mjs';
const b = await launch(); const out = {};
const ctx = await newCtx(b, 'customer'); const p = await ctx.newPage();
await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' }); await settle(p, 1200);
// phone: compare the drawn order of the number's characters. Render check: left-to-right x of "+" vs last digit
out.phoneDrawnLTR = await p.evaluate(() => { const a = document.querySelector('header a[href^="tel:"]'); const t = a.firstChild; const r = document.createRange(); r.setStart(t, 0); r.setEnd(t, 1); const first = r.getBoundingClientRect().left; r.setStart(t, t.length - 1); r.setEnd(t, t.length); const last = r.getBoundingClientRect().left; return { plusLeftOfLastDigit: first < last, dirComputed: getComputedStyle(a).direction }; });
// gradient: element with the fade overlay inside the big category card
out.gradient = await p.evaluate(() => [...document.querySelectorAll('div.absolute.inset-0')].filter(e => /gradient/.test(getComputedStyle(e).backgroundImage)).slice(0, 3).map(e => (getComputedStyle(e).backgroundImage.match(/linear-gradient\((to \w+|[\d.]+deg)/) || [])[1]));
const cat = p.locator('h2').filter({ hasText: 'آرایش' }).locator('xpath=ancestor::div[contains(@class,"rounded-2xl")][1]'); await cat.scrollIntoViewIfNeeded(); await cat.screenshot({ path: 'shots/fix-promo-card.png' });
await p.goto(BASE + '/contact', { waitUntil: 'domcontentloaded' }); await settle(p);
const em = p.locator('input[type=email]').first(); await em.fill('ali.reza@example.com.'); await em.evaluate(e => e.blur()); await em.locator('xpath=..').screenshot({ path: 'shots/fix-email.png' });
const m = await newCtx(b, 'admin', { width: 390, height: 844 }); const q = await m.newPage();
await q.goto(BASE + '/admin/analytics', { waitUntil: 'domcontentloaded' }); await settle(q, 1200);
out.analyticsMobile = await q.evaluate(() => { const mn = document.querySelector('main'); return { clientW: mn.clientWidth, scrollW: mn.scrollWidth }; });
await b.close(); console.log(JSON.stringify(out));
