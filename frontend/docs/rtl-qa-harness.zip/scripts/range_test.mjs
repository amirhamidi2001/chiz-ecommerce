import { launch, newCtx, settle, BASE } from './harness.mjs';
const b = await launch(); const ctx = await newCtx(b, 'anon'); const p = await ctx.newPage();
await p.goto(BASE + '/category', { waitUntil: 'domcontentloaded' }); await settle(p, 1200);
const info = await p.evaluate(() => [...document.querySelectorAll('input[type=range]')].map(i => { const r = i.getBoundingClientRect(); return { min: i.min, max: i.max, val: i.value, dir: getComputedStyle(i).direction, l: Math.round(r.left), r: Math.round(r.right), y: Math.round(r.top + r.height / 2), cls: String(i.className).slice(0, 50) }; }));
console.log(JSON.stringify(info));
const rg = p.locator('input[type=range]').first(); const bb = await rg.boundingBox();
// click 25% in from the RIGHT edge: native RTL slider => value near 25% of max if min is at the right
await p.mouse.click(bb.x + bb.width * 0.75, bb.y + bb.height / 2); await p.waitForTimeout(400);
const afterClick = await rg.inputValue();
await rg.focus(); const v0 = await rg.inputValue(); await p.keyboard.press('ArrowLeft'); const vL = await rg.inputValue(); await p.keyboard.press('ArrowRight'); await p.keyboard.press('ArrowRight'); const vR = await rg.inputValue();
const inputs = await p.evaluate(() => [...document.querySelectorAll('input[type=number]')].map(i => i.value));
console.log(JSON.stringify({ afterClickAt25pctFromRight: afterClick, key: { start: v0, afterArrowLeft: vL, afterArrowRightx2: vR }, numberInputs: inputs }));
await b.close();
