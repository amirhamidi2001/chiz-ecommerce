"""QA-only Persian seed data. NOT part of the repo. Run: python seed_fa.py (inside manage.py shell)."""
import io, random, datetime
from decimal import Decimal
from PIL import Image, ImageDraw
from django.core.files.base import ContentFile
from django.db import transaction
from django.utils import timezone
from django.contrib.auth import get_user_model
from shop.models import *
from promotions.models import Coupon, FlashSale
from order.models import Order, OrderItem
from shipping.models import ShippingCarrier, ShippingRate, Shipment
from payments.models import PaymentTransaction
from dashboard.models import Address, Wishlist
from accounts.models import Profile

random.seed(7)
U = get_user_model()
T = lambda toman: toman * 10  # Toman -> Rial

def png(label_hue, w=800, h=800, text=None):
    im = Image.new("RGB", (w, h), (255, 255, 255))
    d = ImageDraw.Draw(im)
    for y in range(h):
        k = y / h
        d.line([(0, y), (w, y)], fill=(int(220 - 60 * k + label_hue % 40), int(190 - 50 * k + (label_hue * 3) % 60), int(200 - 40 * k + (label_hue * 7) % 50)))
    # asymmetric motif so mirroring bugs are visible in screenshots: bar on the LEFT, dot top-right
    d.rectangle([0, 0, w // 8, h], fill=(40, 40, 40))
    d.ellipse([w - 160, 40, w - 40, 160], fill=(255, 255, 255))
    d.rectangle([w // 4, h // 3, 3 * w // 4, 2 * h // 3], outline=(255, 255, 255), width=8)
    buf = io.BytesIO(); im.save(buf, "PNG"); return ContentFile(buf.getvalue())

with transaction.atomic():
    for M in [Wishlist, OrderItem, PaymentTransaction, Shipment, Order, ReviewImage, Review, FlashSale, Coupon, ProductVariant, ProductColor, ProductImage, Product, Brand, Category, Color, ShippingRate, ShippingCarrier, Address]:
        M.objects.all().delete()

    cats = {}
    tree = {"مراقبت از پوست": ["کرم مرطوب‌کننده", "سرم و ضد پیری", "ضدآفتاب"], "آرایش": ["رژ لب", "کرم پودر", "ریمل و خط چشم"], "مراقبت از مو": ["شامپو", "ماسک مو"], "عطر و ادکلن": []}
    slugs = {"مراقبت از پوست": "skincare", "آرایش": "makeup", "مراقبت از مو": "haircare", "عطر و ادکلن": "fragrance"}
    for i, (parent, subs) in enumerate(tree.items()):
        p = Category.objects.create(name=parent, slug=slugs[parent]); p.image.save(f"c{i}.png", png(i * 30, 600, 400), save=True); cats[parent] = p
        for j, s in enumerate(subs):
            c = Category.objects.create(name=s, parent=p, slug=f"{slugs[parent]}-{j}"); c.image.save(f"c{i}{j}.png", png(i * 30 + j * 11, 600, 400), save=True); cats[s] = c

    brands = {}
    for n, s in [("لورآل", "loreal"), ("نیوآ", "nivea"), ("گلدن رز", "golden-rose"), ("سینره", "cinere"), ("L'Oréal Paris Professional", "lp")]:
        b = Brand.objects.create(name=n, slug=s); b.logo.save(f"{s}.png", png(len(s) * 20, 300, 300), save=True); brands[n] = b

    colors = {}
    for n, h in [("صورتی گلبهی", "#E8A0B4"), ("قرمز آتشین", "#C0262B"), ("بژ طبیعی", "#E2C3A0"), ("رزگلد", "#B76E79"), ("مشکی", "#111111"), ("نارنجی مرجانی", "#F2785C")]:
        colors[n] = Color.objects.create(name=n, hex_code=h)

    # (name, category, brand, base_toman, discount?, skin, spf, variants[(color|None, vol, price delta, stock)], flags)
    P = [
        ("کرم مرطوب‌کننده روزانه مناسب پوست خشک", "کرم مرطوب‌کننده", "نیوآ", 389000, 0, "dry", None, [(None, 50, 0, 40), (None, 100, 220000, 25)]),
        ("سرم ویتامین سی ۱۵٪ روشن‌کننده و ضد لک با فرمول پیشرفته و ماندگاری بالا مناسب انواع پوست", "سرم و ضد پیری", "لورآل", 1250000, 20, "all", None, [(None, 30, 0, 12)]),
        ("ضدآفتاب بی‌رنگ SPF50+ مناسب پوست چرب", "ضدآفتاب", "سینره", 495000, 0, "oily", 50, [(None, 50, 0, 60), (None, 75, 150000, 0)]),
        ("رژ لب مایع مات ماندگار", "رژ لب", "گلدن رز", 285000, 15, None, None, [("صورتی گلبهی", None, 0, 30), ("قرمز آتشین", None, 0, 22), ("رزگلد", None, 10000, 5), ("نارنجی مرجانی", None, 0, 0)]),
        ("کرم پودر مات Matte Foundation 24H", "کرم پودر", "L'Oréal Paris Professional", 720000, 0, "combination", 15, [("بژ طبیعی", 30, 0, 18), ("رزگلد", 30, 0, 9)]),
        ("ریمل حجم‌دهنده ضدآب", "ریمل و خط چشم", "گلدن رز", 340000, 0, None, None, [("مشکی", None, 0, 50)]),
        ("شامپو ترمیم‌کننده موهای رنگ‌شده", "شامپو", "لورآل", 265000, 10, None, None, [(None, 250, 0, 33), (None, 400, 120000, 21)]),
        ("ماسک مو کراتین", "ماسک مو", "سینره", 410000, 0, None, None, [(None, 200, 0, 15)]),
        ("ادکلن زنانه گل‌های بهاری", "عطر و ادکلن", "لورآل", 2150000, 0, None, None, [(None, 100, 0, 8)]),
    ]
    for i in range(10):
        P.append((f"محصول نمونه شماره {i + 10} برای صفحه‌بندی", "کرم مرطوب‌کننده", "نیوآ", 150000 + i * 31000, 0, "normal", None, [(None, 50, 0, 20)]))

    products = []
    for idx, (name, cat, br, base, disc, skin, spf, vars_) in enumerate(P):
        orig = T(base)
        price = T(base * (100 - disc) // 100) if disc else orig
        p = Product.objects.create(
            category=cats[cat], brand=brands[br], name=name, slug=f"p{idx + 1}",
            short_description="توضیح کوتاه محصول: " + name[:40],
            description="این یک توضیح کامل فارسی برای محصول است. " * 6 + "\n\nمناسب استفاده روزانه، فرمول سبک و بدون چربی. Made in France — کد IRC: 1234567890.",
            ingredients="Aqua, Glycerin, Niacinamide, Tocopherol, عصاره آلوئه‌ورا, Parfum",
            usage_instructions="صبح و شب روی پوست تمیز استفاده کنید.", warnings="در صورت تماس با چشم با آب فراوان بشویید.",
            country_of_origin="فرانسه", price=price, original_price=orig if disc else None, stock=sum(v[3] for v in vars_),
            rating=Decimal(str(round(random.uniform(3.2, 4.9), 1))), reviews_count=0, is_new=idx % 3 == 0, is_sale=bool(disc),
            is_cruelty_free=idx % 2 == 0, is_vegan=idx % 3 == 1, is_organic=idx % 4 == 0, skin_type=skin or "", spf=spf,
        )
        p.thumbnail.save(f"t{idx}.png", png(idx * 23), save=True)
        for g in range(3):
            pi = ProductImage(product=p); pi.image.save(f"g{idx}-{g}.png", png(idx * 23 + g * 17), save=True)
        for (cn, vol, delta, stock) in vars_:
            ProductVariant.objects.create(product=p, color=colors.get(cn) if cn else None, volume_ml=vol, price=price + T(delta) if delta else price,
                                          original_price=(orig + T(delta)) if disc else None, stock=stock, is_active=True)
            if cn: ProductColor.objects.get_or_create(product=p, color=colors[cn])
        products.append(p)

    # users
    cust = U.objects.filter(email="customer@qa.test").first() or U.objects.create_user(email="customer@qa.test", password="QaPass!234", is_verified=True, phone_number="09121234567")
    admin = U.objects.filter(email="admin@qa.test").first() or U.objects.create_user(email="admin@qa.test", password="QaPass!234", is_verified=True, type=2, is_staff=True, is_superuser=True)
    for u, fn, ln in [(cust, "علیرضا", "محمدی‌نژاد"), (admin, "مدیر", "فروشگاه")]:
        pr, _ = Profile.objects.get_or_create(user=u); pr.first_name, pr.last_name = fn, ln; pr.phone_number = "09121234567"; pr.save()

    reviewers = []
    for i in range(6):
        e = f"r{i}@qa.test"; reviewers.append(U.objects.filter(email=e).first() or U.objects.create_user(email=e, password="x", is_verified=True))

    # reviews (+images, store reply, long text, mixed script)
    texts = ["عالی بود، دقیقاً همان چیزی که انتظار داشتم. بسته‌بندی هم خیلی مرتب بود و سریع رسید.",
             "کیفیت خوبه ولی قیمتش یکم بالاست. Texture خیلی سبک و جذب سریع.",
             "بعد از ۲ هفته استفاده نتیجه رو دیدم. " * 8,
             "متوسط. انتظار بیشتری داشتم!"]
    for pi_, p in enumerate(products[:5]):
        for k in range(4):
            r = Review.objects.create(product=p, user=reviewers[k], name=["سارا احمدی", "Reza K.", "مریم", "نگار رضایی‌فر"][k], rating=[5, 4, 5, 3][k], headline=["خیلی راضیم", "Good but pricey", "نتیجه عالی", "معمولی"][k],
                                      comment=texts[k], is_verified_purchase=k % 2 == 0, is_approved=True)
            if k in (0, 2):
                for g in range(3 if k == 0 else 1):
                    ri = ReviewImage(review=r); ri.image.save(f"rv{pi_}{k}{g}.png", png(pi_ * 40 + g * 13, 500, 500), save=True)
            if k == 0 and pi_ in (0, 1):
                r.store_response = "از اعتماد شما سپاسگزاریم. امیدواریم همچنان همراه ما باشید."; r.store_response_at = timezone.now(); r.save()
        p.reviews_count = 4; p.save(update_fields=["reviews_count"])

    # promotions
    now = timezone.now()
    fs = FlashSale.objects.create(name="حراج ویژه آخر هفته", discount_percent=Decimal("25"), starts_at=now - datetime.timedelta(hours=1), ends_at=now + datetime.timedelta(hours=5, minutes=30), is_active=True)
    fs.products.set(products[:4])
    Coupon.objects.create(code="SAVE10", discount_type="percent", percent_off=Decimal("10"), valid_from=now - datetime.timedelta(days=1), valid_until=now + datetime.timedelta(days=30), is_active=True)
    Coupon.objects.create(code="FIX50K", discount_type="fixed", fixed_amount=T(50000), min_order_amount=T(300000), valid_from=now - datetime.timedelta(days=1), valid_until=now + datetime.timedelta(days=30), is_active=True)
    Coupon.objects.create(code="OLD2020", discount_type="percent", percent_off=Decimal("5"), valid_from=now - datetime.timedelta(days=400), valid_until=now - datetime.timedelta(days=300), is_active=False)

    # shipping
    for code, name, same in [("post", "پست پیشتاز", False), ("tipax", "تیپاکس", False), ("snapbox", "اسنپ‌باکس", True), ("alopeyk", "الوپیک", True)]:
        c = ShippingCarrier.objects.create(code=code, display_name=name, supports_same_day=same, is_active=True)
        ShippingRate.objects.create(carrier=c, province="tehran", min_weight_g=0, max_weight_g=100000, price=T({"post": 45000, "tipax": 65000, "snapbox": 90000, "alopeyk": 110000}[code]),
                                    estimated_days_min=0 if same else 2, estimated_days_max=1 if same else 5, is_active=True)

    # addresses
    Address.objects.create(user=cust, label="home", first_name="علیرضا", last_name="محمدی‌نژاد", phone="09121234567", address_line="تهران، خیابان ولیعصر، نرسیده به میدان ونک، کوچه گلستان، پلاک ۱۲", apartment="واحد ۴", city="تهران", province="tehran", postal_code="1234567890", is_default=True)
    Address.objects.create(user=cust, label="office", first_name="علیرضا", last_name="محمدی‌نژاد", phone="09121234567", address_line="اصفهان، خیابان چهارباغ عباسی، ساختمان آرمان، طبقه سوم", city="اصفهان", province="isfahan", postal_code="8134567890")

    # orders
    post = ShippingCarrier.objects.get(code="post")
    for n, (status, ship) in enumerate([("pending", None), ("processing", None), ("shipped", "in_transit"), ("delivered", "delivered"), ("cancelled", None)]):
        o = Order.objects.create(order_number=f"CHZ-2026-{1001 + n}", user=cust, status=status, first_name="علیرضا", last_name="محمدی‌نژاد", email="customer@qa.test", phone="09121234567",
                                 shipping_address="تهران، خیابان ولیعصر، کوچه گلستان، پلاک ۱۲", shipping_apartment="واحد ۴", shipping_city="تهران", shipping_state="tehran", shipping_zip="1234567890", shipping_country="IR",
                                 payment_method="credit_card", card_last_four="4417", shipping_carrier=post, subtotal=T(700000), shipping_cost=T(45000), tax=T(63000), discount=T(0), total=T(808000))
        for p in products[n:n + 2]:
            v = p.variants.first(); OrderItem.objects.create(order=o, product=p, variant=v, product_name=p.name, product_slug=p.slug, variant_sku=v.sku or "", unit_price=v.price, quantity=1 + n % 2)
        Order.objects.filter(pk=o.pk).update(created_at=now - datetime.timedelta(days=10 - n * 2))
        PaymentTransaction.objects.create(order=o, gateway="zarinpal", status="success" if status != "pending" else "pending", authority=f"A{n}", amount=o.total)
        if ship:
            Shipment.objects.create(order=o, carrier=post, tracking_number=f"RR{n}2345678IR", status=ship, last_tracked_at=now - datetime.timedelta(hours=3))

    for p in products[5:9]:
        Wishlist.objects.create(user=cust, product=p)
print("seeded", Product.objects.count(), "products;", ProductVariant.objects.count(), "variants")
