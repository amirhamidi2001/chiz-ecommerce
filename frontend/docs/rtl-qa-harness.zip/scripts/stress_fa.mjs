import { launch, newCtx, watch, settle, audit, BASE } from './harness.mjs';
import fs from 'node:fs';
const POOL = ['کتاب','سفارش','محصول','خرید','تحویل','پرداخت','سبد','کالا','قیمت','تخفیف','ارسال','حساب','کاربری','نشانی','تهران','مشتری','فروشگاه','پشتیبانی','بازگشت','جستجو','موجودی','رنگ','مقدار','جمع','مالیات','کد','ثبت','ورود','خروج','مشاهده','همه','جدید','پرفروش','ویژه','حراج','شیوه','گزینه','انتخاب','نمایش','بیشتر'];
const pick = (len, seed) => { const c = POOL.filter(w => Math.abs(w.length - len) <= 1); const pool = c.length ? c : POOL; return pool[seed % pool.length]; };
const b = await launch(); const res = {};
const PAGES = [['home','/','customer'],['category','/category','anon'],['pdp','/product/p4','anon'],['cart','/cart','customer'],['checkout','/checkout','customer'],['account-orders','/account?tab=orders','customer'],['login','/login','anon'],['admin-orders','/admin/orders','admin'],['admin-coupons','/admin/coupons','admin']];
for (const vpn of ['desktop','mobile']) {
  const vp = vpn === 'desktop' ? { width: 1366, height: 900 } : { width: 390, height: 844 };
  const ctxs = {};
  for (const [id, path, role] of PAGES) {
    ctxs[role] ??= await newCtx(b, role, vp); const p = await ctxs[role].newPage(); watch(p);
    await p.goto(BASE + path, { waitUntil: 'domcontentloaded' }); await settle(p, 1000);
    await p.evaluate(([pool]) => {
      let seed = 0; const W = (len) => { const c = pool.filter(w => Math.abs(w.length - len) <= 1); const q = c.length ? c : pool; return q[(seed++) % q.length]; };
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
      for (const n of nodes) { if (n.parentElement.closest('script,style,noscript')) continue; if (/[\u0600-\u06FF]/.test(n.textContent)) continue; n.textContent = n.textContent.replace(/[A-Za-z]{2,}/g, (m) => W(m.length)); }
      for (const el of document.querySelectorAll('[placeholder]')) el.placeholder = el.placeholder.replace(/[A-Za-z]{2,}/g, (m) => W(m.length));
    }, [POOL]);
    await p.waitForTimeout(300);
    const a = await audit(p);
    await p.screenshot({ path: `shots/fa-${vpn}-${id}.png`, fullPage: true });
    res[`${vpn}:${id}`] = { ovf: a.docOverflowPx, clipped: a.clipped.map(c => `${c.el.slice(0, 60)} [${c.left}..${c.right}]`), leftHug: a.leftHug.map(x => x.el.slice(0, 60) + ` L${x.leftGap}/R${x.rightGap}`), ltrFa: a.ltrPersian.map(x => x.el.slice(0, 60)) };
    console.log(`${vpn}:${id}`.padEnd(26), `ovf=${a.docOverflowPx} clip=${a.clipped.length} leftHug=${a.leftHug.length} ltrFa=${a.ltrPersian.length}`);
    await p.close();
  }
  for (const c of Object.values(ctxs)) await c.close();
}
fs.writeFileSync('results-stress.json', JSON.stringify(res, null, 1)); await b.close();
