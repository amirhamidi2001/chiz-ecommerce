import { tokens, API } from './harness.mjs';
const t = await tokens('customer@qa.test'); const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t.access };
await fetch(`${API}/cart/clear/`, { method: 'DELETE', headers: H }).catch(() => {});
for (const [variant_id, quantity] of [[27, 2], [32, 1], [29, 1]]) {
  const r = await fetch(`${API}/cart/`, { method: 'POST', headers: H, body: JSON.stringify({ variant_id, quantity }) }); console.log('add', variant_id, r.status, (await r.text()).slice(0, 120));
}
const c = await (await fetch(`${API}/cart/`, { headers: H })).json(); console.log(Object.keys(c), c.items?.length, JSON.stringify(c.items?.[0]).slice(0, 300));
