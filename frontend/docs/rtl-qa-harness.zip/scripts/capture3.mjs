import { launch, newCtx, watch, settle, audit, BASE } from './harness.mjs';
const b = await launch(); const out = {};
const brief = (a) => ({ ovf: a.docOverflowPx, clipped: a.clipped.map(c => `${c.el.slice(0,50)} [${c.left}..${c.right}]`), ltrFa: a.ltrPersian.length, leftHug: a.leftHug.map(x => x.el.slice(0,50)) });
const S = async (name, fn) => { try { await fn(); } catch (e) { out[name + '_ERR'] = String(e).slice(0, 220); } console.log(name, JSON.stringify(out[name] ?? out[name + '_ERR'])); };
async function go(ctx, path) { const p = await ctx.newPage(); watch(p); await p.goto(BASE + path, { waitUntil: 'domcontentloaded' }); await settle(p, 1000); return p; }

await S('recommended', async () => {
  const ctx = await newCtx(b, 'customer'); let p = await go(ctx, '/product/p1'); await p.close(); p = await go(ctx, '/product/p4'); await p.close();
  p = await go(ctx, '/'); const h = p.locator('h2,h3').filter({ hasText: /Recommended/i }).first(); out.recommended = { found: await h.count() };
  if (out.recommended.found) { const sec = h.locator('xpath=ancestor::section[1]'); await sec.scrollIntoViewIfNeeded(); await sec.screenshot({ path: 'shots/c-recommended.png' }); out.recommended.audit = brief(await audit(p)); }
  await ctx.close();
});
await S('categoryFacets', async () => {
  const ctx = await newCtx(b, 'anon'); const p = await go(ctx, '/category?category=skincare');
  await p.screenshot({ path: 'shots/c-category-desktop.png', fullPage: false }); out.categoryFacets = { desktop: brief(await audit(p)) };
  await ctx.close();
  const m = await newCtx(b, 'anon', { width: 390, height: 844 }); const q = await go(m, '/category');
  const f = q.getByRole('button', { name: /filter/i }).first(); out.categoryFacets.mobileFilterBtn = await f.count();
  if (out.categoryFacets.mobileFilterBtn) { await f.click(); await q.waitForTimeout(700); }
  await q.screenshot({ path: 'shots/c-category-mobile-filters.png' }); out.categoryFacets.mobile = brief(await audit(q));
  out.categoryFacets.panel = await q.evaluate(() => [...document.querySelectorAll('aside,[class*="fixed"]')].filter(e => e.getBoundingClientRect().width > 100).slice(0, 3).map(e => ({ c: String(e.className).slice(0, 60), l: Math.round(e.getBoundingClientRect().left), r: Math.round(e.getBoundingClientRect().right) })));
  await m.close();
});
await S('accountTabs', async () => {
  const ctx = await newCtx(b, 'customer');
  for (const t of ['orders', 'wishlist', 'addresses', 'reviews', 'settings', 'payments']) {
    const p = await go(ctx, `/account?tab=${t}`);
    if (t === 'orders') { await p.locator('text=CHZ-2026-1003').first().click({ timeout: 2500 }).catch(() => {}); await p.waitForTimeout(800); out.ordersTrackingWidget = await p.locator('text=/RR32345678IR|tracking/i').count(); }
    await p.screenshot({ path: `shots/c-account-${t}.png`, fullPage: true }); (out.accountTabs ??= {})[t] = brief(await audit(p)); await p.close();
  }
  await ctx.close();
});
await S('adminCoupon', async () => {
  const ctx = await newCtx(b, 'admin'); const p = await go(ctx, '/admin/coupons');
  await p.getByRole('button', { name: /add|new|create/i }).first().click(); await p.waitForTimeout(600);
  const dp = p.locator('button:has(i.bi-calendar), input[placeholder*="YYYY" i], [class*="Jalali"]').first(); out.adminCoupon = { pickerTrigger: await dp.count() };
  await dp.click({ timeout: 2000 }).catch(() => {}); await p.waitForTimeout(500);
  await p.screenshot({ path: 'shots/c-admin-coupon-picker.png' }); out.adminCoupon.audit = brief(await audit(p));
  await ctx.close();
});
await b.close();
