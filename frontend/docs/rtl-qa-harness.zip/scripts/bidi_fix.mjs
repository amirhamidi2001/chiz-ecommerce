import { launch, newCtx, settle, BASE } from './harness.mjs';
const b = await launch(); const ctx = await newCtx(b, 'customer'); const p = await ctx.newPage();
await p.goto(BASE + '/contact', { waitUntil: 'domcontentloaded' }); await settle(p);
const email = p.locator('input[type=email]').first(); await email.scrollIntoViewIfNeeded();
const shots = [];
for (const [label, css] of [['A-current', ''], ['B-plaintext', 'input[type=email]{unicode-bidi:plaintext}'], ['C-dir-ltr', '']]) {
  const h = await p.addStyleTag({ content: css || '/* none */' });
  if (label === 'C-dir-ltr') await email.evaluate(e => e.setAttribute('dir', 'ltr'));
  await email.fill(''); await email.fill('ali.reza@example.com.'); await email.evaluate(e => e.blur());
  const f = `shots/bf-${label}.png`; await email.locator('xpath=..').screenshot({ path: f }); shots.push(f);
  await h.evaluate(n => n.remove()); await email.evaluate(e => e.removeAttribute('dir'));
}
// also empty-state placeholder alignment for B
await b.close(); console.log(shots.join(' '));
