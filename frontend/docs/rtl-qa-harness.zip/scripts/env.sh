export PYTHONPATH=/home/claude/qa:/home/claude/proj/chiz-ecommerce-main/backend
export DJANGO_SETTINGS_MODULE=qa_settings
export SECRET_KEY=qa-secret-not-for-production
export DATABASE_NAME=chiz DATABASE_USER=postgres DATABASE_PASSWORD= DATABASE_HOST=/home/claude/qa/pgdata DATABASE_PORT=5432
export MONEY_REBASELINE_CONFIRMED=true
. /home/claude/venv/bin/activate
