import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'node:fs';
export const BASE = 'http://localhost:5173', API = 'http://localhost:8000/api';
const ICONS = '/home/claude/qa/icons/package/font/';

export async function tokens(email) {
  const r = await fetch(`${API}/auth/login/`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: 'QaPass!234' }) });
  return r.json();
}
export async function launch() {
  return chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'] });
}
/** role: anon|customer|admin ; vp: {width,height} */
export async function newCtx(browser, role = 'anon', vp = { width: 1366, height: 900 }) {
  const ctx = await browser.newContext({ viewport: vp, locale: 'fa-IR', timezoneId: 'Asia/Tehran' });
  // Serve Bootstrap Icons locally (sandbox has no internet; same 1.11.3 files the CDN serves).
  await ctx.route(/cdnjs\.cloudflare\.com\/ajax\/libs\/bootstrap-icons\/1\.11\.3\/font\//, async (route) => {
    const u = new URL(route.request().url()); const rel = u.pathname.split('/font/')[1];
    const f = ICONS + rel;
    if (fs.existsSync(f)) return route.fulfill({ path: f, headers: { 'access-control-allow-origin': '*' } });
    return route.abort();
  });
  if (role !== 'anon') {
    const t = await tokens(role === 'admin' ? 'admin@qa.test' : 'customer@qa.test');
    await ctx.addInitScript(([a, r]) => { localStorage.setItem('access_token', a); localStorage.setItem('refresh_token', r); }, [t.access, t.refresh]);
  }
  return ctx;
}
export function watch(page) {
  const log = { errors: [], failed: [] };
  page.on('pageerror', e => log.errors.push('pageerror: ' + e.message.slice(0, 200)));
  page.on('console', m => { if (m.type() === 'error' && !/ERR_NAME_NOT_RESOLVED|favicon/.test(m.text())) log.errors.push('console: ' + m.text().slice(0, 200)); });
  page.on('response', r => { if (r.status() >= 400 && r.url().startsWith(API)) log.failed.push(`${r.status()} ${r.request().method()} ${r.url().replace(API, '')}`); });
  return log;
}
export async function settle(page, ms = 700) {
  await page.waitForLoadState('networkidle').catch(() => {});
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(ms);
}

/** Runs inside the page. Returns RTL findings. */
export function auditFn() {
  const vw = document.documentElement.clientWidth;
  const PERSIAN = /[\u0600-\u06FF]/;
  const res = { vw, docOverflowPx: Math.max(0, document.documentElement.scrollWidth - vw), clipped: [], ltrPersian: [], leftHug: [], inputs: [], scrollers: [], icons: [], dirAttrs: [] };
  const vis = (el) => { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none' && +cs.opacity > 0.01; };
  const name = (el) => { let s = el.tagName.toLowerCase(); if (el.id) s += '#' + el.id; const c = (typeof el.className === 'string' ? el.className : '').trim().split(/\s+/).filter(Boolean).slice(0, 4).join('.'); if (c) s += '.' + c; const t = (el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 30); return s + (t ? ` "${t}"` : ''); };
  const clipAncestor = (el) => { for (let p = el.parentElement; p && p !== document.documentElement; p = p.parentElement) { const o = getComputedStyle(p).overflowX; if (o !== 'visible') return p; } return null; };
  const fixedAncestor = (el) => { for (let p = el; p; p = p.parentElement) if (getComputedStyle(p).position === 'fixed') return true; return false; };
  const all = [...document.body.querySelectorAll('*')];

  // 1. leaks beyond viewport that are not clipped by an overflow container
  for (const el of all) {
    if (!vis(el)) continue; const r = el.getBoundingClientRect();
    if (r.left < -1 || r.right > vw + 1) {
      const ca = clipAncestor(el);
      if (ca) { const cr = ca.getBoundingClientRect(); if (r.left >= cr.left - 1 && r.right <= cr.right + 1) continue; if (cr.left >= -1 && cr.right <= vw + 1) continue; }
      if (el.closest('svg') && el.tagName !== 'svg') continue;
      // skip elements whose parent already leaks the same way (report roots only)
      const pr = el.parentElement.getBoundingClientRect(); if (pr.left < -1 || pr.right > vw + 1) continue;
      res.clipped.push({ el: name(el), left: Math.round(r.left), right: Math.round(r.right), fixed: fixedAncestor(el) });
    }
  }
  // 2. Persian text laid out LTR; text hugging the physical left edge of a wider box
  const seen = new Set();
  for (const el of all) {
    if (!vis(el)) continue;
    const own = [...el.childNodes].filter(n => n.nodeType === 3 && PERSIAN.test(n.textContent) && n.textContent.trim().length > 1);
    if (!own.length) continue;
    const cs = getComputedStyle(el);
    if (cs.direction === 'ltr' && !el.closest('[dir=ltr]')?.hasAttribute('data-ok')) res.ltrPersian.push({ el: name(el), dir: el.getAttribute('dir') || '(inherited)' });
    if (cs.display === 'inline' || seen.has(el)) continue; seen.add(el);
    const range = document.createRange(); range.selectNodeContents(el); const tr = range.getBoundingClientRect(); const r = el.getBoundingClientRect();
    const padL = parseFloat(cs.paddingLeft), padR = parseFloat(cs.paddingRight);
    const lg = tr.left - (r.left + padL), rg = (r.right - padR) - tr.right;
    if (r.width - tr.width > 60 && cs.textAlign !== 'center' && cs.textAlign !== 'justify' && lg < 6 && rg > 50 && cs.display !== 'flex' && cs.display !== 'inline-flex') res.leftHug.push({ el: name(el), textAlign: cs.textAlign, leftGap: Math.round(lg), rightGap: Math.round(rg) });
  }
  // 3. form controls
  for (const el of document.querySelectorAll('input,textarea,select')) {
    if (!vis(el) || ['hidden', 'checkbox', 'radio', 'file', 'submit', 'button'].includes(el.type)) continue;
    const cs = getComputedStyle(el); const lab = el.id && document.querySelector(`label[for="${el.id}"]`) || el.closest('label');
    res.inputs.push({ el: name(el).replace(/ ".*"$/, ''), type: el.type || el.tagName.toLowerCase(), dirAttr: el.getAttribute('dir'), direction: cs.direction, textAlign: cs.textAlign, placeholder: (el.placeholder || '').slice(0, 24), labelAlign: lab ? getComputedStyle(lab).textAlign : null, name: el.name || el.id || '' });
  }
  // 4. horizontal scrollers
  for (const el of all) {
    const cs = getComputedStyle(el);
    if (['auto', 'scroll'].includes(cs.overflowX) && el.scrollWidth > el.clientWidth + 2 && vis(el)) {
      const first = el.firstElementChild?.getBoundingClientRect(), r = el.getBoundingClientRect();
      res.scrollers.push({ el: name(el), direction: cs.direction, scrollLeft: Math.round(el.scrollLeft), scrollW: el.scrollWidth, clientW: el.clientWidth, firstChildStartsAt: first ? (Math.abs(first.right - r.right) < 24 ? 'right-edge' : Math.abs(first.left - r.left) < 24 ? 'left-edge' : 'mid') : null });
    }
  }
  // 5. directional icons: effective VISUAL direction + accessible name of nearest control
  for (const el of document.querySelectorAll('i[class*="bi-"], span[class*="bi-"]')) {
    const m = (el.className.match(/bi-((?:arrow|chevron|caret|box-arrow|text|reply|send|skip|rewind|fast-forward|arrow-return)[\w-]*?)(?:-(left|right))?(?![\w-])/g) || []).join(' ');
    const cls = el.className; const dm = cls.match(/bi-(?:[a-z-]*?)(left|right)\b/); if (!dm || !vis(el)) continue;
    const mirrored = getComputedStyle(el).scale === '-1 1' || getComputedStyle(el).scale === '-1';
    const glyph = dm[1]; const visual = mirrored ? (glyph === 'left' ? 'right' : 'left') : glyph;
    const host = el.closest('button,a,[role=button]'); const rr = el.getBoundingClientRect();
    res.icons.push({ icon: cls.split(/\s+/).find(c => /^bi-/.test(c) && c !== 'bi'), mirrored, visualPoints: visual, inControl: host ? ((host.getAttribute('aria-label') || host.getAttribute('title') || host.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 28)) : null, x: Math.round(rr.left), y: Math.round(rr.top + scrollY) });
  }
  // 6. explicit dir attributes (for review)
  for (const el of document.querySelectorAll('[dir]')) if (el !== document.documentElement && vis(el)) res.dirAttrs.push(name(el).slice(0, 60) + ' dir=' + el.getAttribute('dir'));
  return res;
}
export async function audit(page) { return page.evaluate(auditFn); }
