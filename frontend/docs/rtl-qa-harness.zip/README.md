# RTL QA harness (Task 14.3.3.1)

Everything used to execute `frontend/docs/rtl-qa-checklist.md`. It is QA tooling, **not** part of the repo.

## What it needs
- Real Postgres + Redis + the Django backend (the app uses Postgres full-text search and `select_for_update`).
- Vite dev server on `:5173`, Django on `:8000`.
- Playwright + a Chromium build (scripts import `playwright` from `/opt/npm-tools/node_modules`; edit the import and the `executablePath` in `harness.mjs`).
- `bootstrap-icons@1.11.3` unpacked to `icons/package/` - the app loads icons from a CDN; `harness.mjs` serves the same files locally so screenshots have icons offline.

## Steps
1. `qa_settings.py` (outside the repo, on `PYTHONPATH`) = development settings with throttling relaxed + `MEDIA_ROOT` outside the repo. `env.sh` shows the env vars used.
2. `python manage.py migrate && python manage.py compilemessages && python manage.py shell < seed_fa.py` - Persian seed data with RTL stress cases (very long names, mixed Persian/Latin, review photos, store reply, flash sale, coupons, orders in every status + shipments, wishlist, 2 addresses). Logins: `customer@qa.test` / `admin@qa.test`, password `QaPass!234`. (`seed_shop` / `seed_blog` are stale and cannot be used - see the checklist.)
3. `node fill_cart.mjs` puts three variants in the customer's cart.
4. `VPS=desktop,mobile node run_pages.mjs routes.json "" results.json` - visits every route, runs the in-page probe (`auditFn` in `harness.mjs`), writes `shots/<viewport>-<id>.png`.
5. Interaction passes: `interact1.mjs`, `interact2.mjs`, `capture3.mjs`, `jalali_test.mjs`, `range_test.mjs`.
6. `stress_fa.mjs` = pseudo-localization: replaces every English word in the rendered DOM with a same-length Persian word. **Re-run the checklist with real Persian copy once it exists; this is only a proxy.**
7. `probe_test.mjs` injects known-bad elements to prove the probe still catches them - run it before trusting a clean sweep.

## What the probe checks
Horizontal page overflow; elements leaking outside the viewport (unless clipped by an overflow container); Persian text laid out LTR; Persian text hugging the physical left edge of a wider box; form-control direction/alignment; horizontal scrollers and where their first child starts; the **visual** direction of every directional icon plus the accessible name of its control. It does NOT judge spacing, aesthetics or semantic correctness of Latin-script copy - that is human review of the screenshots.

## Gotchas
- Background servers die when a tool call ends in some sandboxes; start them detached (`setsid nohup ... &`).
- Chromium forces `direction: ltr` on `input[type=tel]` but not on `email`/`url`/`text`.
- `main` in the admin layout is its own scroller, so `fullPage` screenshots capture only the viewport there.
